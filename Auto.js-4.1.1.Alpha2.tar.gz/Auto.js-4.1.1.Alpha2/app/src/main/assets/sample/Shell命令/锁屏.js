KeyCode("KEYCODE_POWER");
//或者 KeyCode(26);