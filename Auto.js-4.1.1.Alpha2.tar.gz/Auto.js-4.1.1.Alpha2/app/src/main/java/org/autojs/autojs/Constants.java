package org.autojs.autojs;

/**
 * Created by Stardust on 2017/7/7.
 */

public final class Constants {


}
