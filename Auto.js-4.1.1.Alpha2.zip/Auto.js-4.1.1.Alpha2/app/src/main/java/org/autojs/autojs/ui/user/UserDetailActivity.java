package org.autojs.autojs.ui.user;

import org.autojs.autojs.ui.BaseActivity;

/**
 * Created by Stardust on 2017/10/26.
 */

public class UserDetailActivity extends WebActivity {

}
